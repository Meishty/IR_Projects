# Blowfish-Cipher

Quick Start

Enter the following to run Blowfish for the given key and message:

make./blow `cat key` < message
