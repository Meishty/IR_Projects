# Tiny-Encryption-Algorithm
Popular with WEP/Used in DC Darknet badge -- simple implementations that will ultimately be used in attacking the badge.
Includes 16, 32, and 64 bit types.
