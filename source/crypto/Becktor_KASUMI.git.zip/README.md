# KASUMI
Implementation of KASUMI in C
