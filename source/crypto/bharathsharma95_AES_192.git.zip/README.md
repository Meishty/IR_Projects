# AES_192
This repo is an implementation of my work towards accelerating the algorithm on FPGAs, specifically on the Xilinx 7 series SoC boards.

This set of source codes and testbenches work on Vivado HLS as to see how they would get synthesized and the characteristics of the implementation on the choice of boards that interest you.

With some minor modifications, you can also use these files to implement it on embedded processors like Arm Cortex A9 with cross-compilation tools installed on your laptop (with linux OS preffered, as it gives you space to play and tweak around with ease). Details for cross compilation can be seen in another file named "______" in the repository
