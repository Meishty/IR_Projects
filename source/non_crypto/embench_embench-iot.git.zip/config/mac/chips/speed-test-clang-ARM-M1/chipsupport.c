/* Chip support for Apple Mac

   Copyright (C) 2019 Clemson University

   Contributor Ola Jeppsson <ola.jeppsson@gmail.com>
   Contributor Roger Shepherd <rog@rcjd.net>

   This file is part of Embench.

   SPDX-License-Identifier: GPL-3.0-or-later */

#include "chipsupport.h"
