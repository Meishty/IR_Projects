/* Copyright (C) 2019 Clemson University

   Contributor Ola Jeppsson <ola.jeppsson@gmail.com>
   Contributor Roger Shepherd <rog@rcjd.net>

   This file is part of Embench.

   SPDX-License-Identifier: GPL-3.0-or-later */

// This value of CPU_MHZ is wrong for all known Macs!
#define CPU_MHZ 1
