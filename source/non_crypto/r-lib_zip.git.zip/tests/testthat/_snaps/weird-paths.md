# backslash is an error

    Code
      zip(tmpzip, tmp, mode = "cherry-pick")
    Condition
      Error in `zip_internal()`:
      ! zip error: Cannot add file `zip-test-bs-<random>/real\bad` to archive `<tempdir>/zip-test-bs-<random>.zip` in file zip.c:<line>

