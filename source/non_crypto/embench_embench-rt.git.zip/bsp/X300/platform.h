/* Copyright(C) 2019 Hex Five Security, Inc. */
/* 10-MAR-2019 Cesare Garlati                */

#define RTC_FREQ 16416
#define MTIME    0x0200BFF8
#define MTIMECMP 0x02004000

